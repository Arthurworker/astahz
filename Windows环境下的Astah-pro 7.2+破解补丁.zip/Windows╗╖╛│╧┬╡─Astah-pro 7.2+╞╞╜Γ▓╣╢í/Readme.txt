﻿////////////////////////////////////////////////////
/author: yhwu                                      /
/E-mail: yuhaow1825@163.com                        /
/URL: https://github.com/Arthurworker/Astah        /
/version: Astah Professional 7.2.0                 /
/time: 2019-05-31                                  /
////////////////////////////////////////////////////
>>options<<
1. 打开astah-professional-7_2_0-1ff236-jre-64bit-setup.exe文件进行安装；
2. 安装完成后先不要启动
；
3. 解压astah-pro.v7.2.0-1ff236.zip
；   
4. 将解压出来的文件astah-pro.jar覆盖到astah的安装目录里；
 
5. 启动Astah Professional，完成破解。